#include <iostream>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstdlib>
#include <ctime>
#include <cstring>

#define PORT 9090

void send_message(int sock, int philosopher_num, const std::string& action) {
    std::string message = std::to_string(philosopher_num) + action;
    send(sock, message.c_str(), message.length(), 0);
    char buffer[1024] = {0};
    int valread = read(sock, buffer, 1024);
    if (valread > 0) {
        std::string response(buffer, valread);
        std::cout << "Client " << philosopher_num << " received: " << response << std::endl;
        if (response == "shutdown") {
            std::cout << "Server abort. Client " << philosopher_num << " exiting.\n";
            close(sock);
            exit(0);
        }
    } else {
        std::cerr << "Error: No response from server or connection lost." << std::endl;
    }
}

int main(int argc, char const *argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: " << argv[0] << " <server_ip> <client_number>\n";
        return 1;
    }

    const char *server_ip = argv[1];
    int philosopher_num = std::stoi(argv[2]);

    int sock = 0;
    struct sockaddr_in serv_addr;
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        std::cout << "Socket creation error\n";
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    if (inet_pton(AF_INET, server_ip, &serv_addr.sin_addr) <= 0) {
        std::cout << "Invalid address/ Address not supported\n";
        return -1;
    }

    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        std::cout << "Connection failed\n";
        return -1;
    }

    // Отправка типа клиента
    char client_type = 'P';
    send(sock, &client_type, 1, 0);

    srand(time(NULL) + philosopher_num);

    while (true) {
        int think_time = rand() % 5 + 1;
        int eat_time = rand() % 5 + 1;

        std::cout << "Client " << philosopher_num << " is thinking for " << think_time << " seconds.\n";
        sleep(think_time);

        send_message(sock, philosopher_num, "request");
        std::cout << "Client " << philosopher_num << " is eating for " << eat_time << " seconds.\n";
        sleep(eat_time);
        send_message(sock, philosopher_num, "release");
    }

    close(sock);
    return 0;
}
