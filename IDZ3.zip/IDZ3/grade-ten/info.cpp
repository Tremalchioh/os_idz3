#include <iostream>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstring>

#define PORT 9090  // Должен совпадать с портом сервера

int main(int argc, char const *argv[]) {
    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <server_ip>\n";
        return 1;
    }

    const char *server_ip = argv[1];

    int sock = 0;
    struct sockaddr_in serv_addr;
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        std::cout << "Socket creation error\n";
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    if (inet_pton(AF_INET, server_ip, &serv_addr.sin_addr) <= 0) {
        std::cout << "Invalid address/ Address not supported\n";
        return -1;
    }

    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        std::cout << "Connection failed\n";
        return -1;
    }

    // Отправка типа клиента
    char client_type = 'M';
    send(sock, &client_type, 1, 0);

    fd_set read_fds;
    struct timeval tv;
    tv.tv_sec = 1;
    tv.tv_usec = 0;

    std::cout << "Connected to server. Waiting for data...\n";

    while (true) {
        FD_ZERO(&read_fds);
        FD_SET(sock, &read_fds);

        int ret = select(sock + 1, &read_fds, NULL, NULL, &tv);
        if (ret > 0 && FD_ISSET(sock, &read_fds)) {
            char buffer[1024];
            int valread = read(sock, buffer, 1024);
            if (valread > 0) {
                std::string response(buffer, valread);
                if (response == "shutdown") {
                    std::cout << "Server abort. Monitor exiting.\n";
                    break;
                }
                std::cout << response << std::endl;
            }
        }
    }

    close(sock);
    return 0;
}
