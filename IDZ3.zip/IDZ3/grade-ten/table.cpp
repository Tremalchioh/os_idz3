#include <iostream>
#include <vector>
#include <string>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <mutex>
#include <ifaddrs.h>
#include <netinet/in.h>
#include <cstring>
#include <thread>
#include <set>
#include <csignal>

#define PORT 9090

std::mutex mtx;
std::vector<bool> forks(5, true);
std::set<int> monitors;
std::set<int> clients;
bool running = true;
int server_fd;

void print_ip_address() {
    struct ifaddrs *ifap, *ifa;
    struct sockaddr_in *sa;
    char *addr;

    getifaddrs(&ifap);
    for (ifa = ifap; ifa; ifa = ifa->ifa_next) {
        if (ifa->ifa_addr->sa_family == AF_INET) {
            sa = (struct sockaddr_in *) ifa->ifa_addr;
            addr = inet_ntoa(sa->sin_addr);
            std::cout << "Interface: " << ifa->ifa_name << " - IP Address: " << addr << std::endl;
        }
    }

    freeifaddrs(ifap);
}

void notify_monitors(const std::string &message) {
    for (int monitor_sock : monitors) {
        send(monitor_sock, message.c_str(), message.length(), 0);
    }
}

void notify_shutdown() {
    std::unique_lock<std::mutex> lock(mtx);
    for (int client_sock : clients) {
        send(client_sock, "shutdown", strlen("shutdown"), 0);
    }
    for (int monitor_sock : monitors) {
        send(monitor_sock, "shutdown", strlen("shutdown"), 0);
    }
}

void handle_client(int client_sock) {
    clients.insert(client_sock);
    char buffer[1024] = {0};
    int valread;
    while ((valread = read(client_sock, buffer, 1024)) > 0) {
        std::string request(buffer, valread);
        std::string response;
        int philosopher_num = request[0] - '0';
        std::string action = request.substr(1);

        if (action == "request") {
            std::unique_lock<std::mutex> lock(mtx);
            int left = philosopher_num;
            int right = (philosopher_num + 1) % 5;
            if (forks[left] && forks[right]) {
                forks[left] = forks[right] = false;
                response = "granted";
                notify_monitors("Client " + std::to_string(philosopher_num) + " took forks " + std::to_string(left) + " and " + std::to_string(right) + "\n");
            } else {
                response = "denied";
            }
        } else if (action == "release") {
            std::unique_lock<std::mutex> lock(mtx);
            int left = philosopher_num;
            int right = (philosopher_num + 1) % 5;
            forks[left] = forks[right] = true;
            response = "released";
            notify_monitors("Client " + std::to_string(philosopher_num) + " released forks " + std::to_string(left) + " and " + std::to_string(right) + "\n");
        }

        send(client_sock, response.c_str(), response.length(), 0);
        memset(buffer, 0, 1024);
    }
    clients.erase(client_sock);
    close(client_sock);
}

void handle_monitor(int monitor_sock) {
    std::unique_lock<std::mutex> lock(mtx);
    monitors.insert(monitor_sock);
    lock.unlock();

    std::string state = "Current state of forks:\n";
    for (size_t i = 0; i < forks.size(); ++i) {
        state += "Fork " + std::to_string(i) + ": " + (forks[i] ? "free" : "taken") + "\n";
    }
    send(monitor_sock, state.c_str(), state.length(), 0);

    char buffer[1024];
    while (read(monitor_sock, buffer, 1024) > 0) {

    }

    lock.lock();
    monitors.erase(monitor_sock);
    lock.unlock();
    close(monitor_sock);
}

void shutdown_server(int signum) {
    std::cout << "Shutting down server...\n";
    notify_shutdown();
    running = false;
    shutdown(server_fd, SHUT_RDWR);
}

int main(int argc, char const *argv[]) {
    print_ip_address();

    int server_fd, new_socket;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);

    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt))) {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }
    if (listen(server_fd, 3) < 0) {
        perror("listen");
        exit(EXIT_FAILURE);
    }

    signal(SIGINT, shutdown_server);

    while (running) {
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen)) < 0) {
            if (!running) {
                break;
            }
            perror("accept");
            exit(EXIT_FAILURE);
        }

        char client_type;
        read(new_socket, &client_type, 1);
        if (client_type == 'M') {
            std::thread(handle_monitor, new_socket).detach();
        } else {
            std::thread(handle_client, new_socket).detach();
        }
    }

    close(server_fd);
    std::cout << "Server aborted successfully." << std::endl;
    return 0;
}
