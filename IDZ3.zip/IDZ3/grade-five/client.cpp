#include <iostream>
#include <vector>
#include <string>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <mutex>
#include <ifaddrs.h>
#include <netinet/in.h>
#include <cstring>
#include <thread>

#define PORT 8080

void send_message(int sock, int philosopher_num, const std::string& action) {
    std::string message = std::to_string(philosopher_num) + action;
    send(sock, message.c_str(), message.length(), 0);
    char buffer[1024] = {0};
    read(sock, buffer, 1024);
    std::string response(buffer);
    std::cout << "Philosopher " << philosopher_num << " received: " << response << std::endl;
}

int main(int argc, char const *argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: " << argv[0] << " <server_ip> <philosopher_number>\n";
        return 1;
    }

    const char *server_ip = argv[1];
    int philosopher_num = std::stoi(argv[2]);

    int sock = 0;
    struct sockaddr_in serv_addr;
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        std::cout << "Socket creation error\n";
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    if (inet_pton(AF_INET, server_ip, &serv_addr.sin_addr) <= 0) {
        std::cout << "Invalid address/ Address not supported\n";
        return -1;
    }

    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        std::cout << "Connection failed\n";
        return -1;
    }

    srand(time(NULL) + philosopher_num);

    while (true) {
        int think_time = rand() % 5 + 1;
        int eat_time = rand() % 5 + 1;

        std::cout << "Philosopher " << philosopher_num << " is thinking for " << think_time << " seconds.\n";
        sleep(think_time);

        send_message(sock, philosopher_num, "request");
        std::cout << "Philosopher " << philosopher_num << " is eating for " << eat_time << " seconds.\n";
        sleep(eat_time);
        send_message(sock, philosopher_num, "release");
    }

    close(sock);
    return 0;
}
