#include <iostream>
#include <vector>
#include <string>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <mutex>
#include <ifaddrs.h>
#include <netinet/in.h>
#include <cstring>
#include <thread>

#define PORT 8080

std::mutex mtx;
std::vector<bool> forks(5, true); // 5 вилок, изначально все свободны

void print_ip_address() {
    struct ifaddrs *ifap, *ifa;
    struct sockaddr_in *sa;
    char *addr;

    getifaddrs(&ifap);
    for (ifa = ifap; ifa; ifa = ifa->ifa_next) {
        if (ifa->ifa_addr->sa_family == AF_INET) {
            sa = (struct sockaddr_in *) ifa->ifa_addr;
            addr = inet_ntoa(sa->sin_addr);
            std::cout << "Interface: " << ifa->ifa_name << " - IP Address: " << addr << std::endl;
        }
    }

    freeifaddrs(ifap);
}

void handle_client(int client_sock) {
    char buffer[1024] = {0};
    int valread;
    while ((valread = read(client_sock, buffer, 1024)) > 0) {
        std::string request(buffer, valread);
        std::string response;
        int philosopher_num = request[0] - '0';
        std::string action = request.substr(1);

        if (action == "request") {
            std::unique_lock<std::mutex> lock(mtx);
            int left = philosopher_num;
            int right = (philosopher_num + 1) % 5;
            if (forks[left] && forks[right]) {
                forks[left] = forks[right] = false;
                response = "granted";
            } else {
                response = "denied";
            }
        } else if (action == "release") {
            std::unique_lock<std::mutex> lock(mtx);
            int left = philosopher_num;
            int right = (philosopher_num + 1) % 5;
            forks[left] = forks[right] = true;
            response = "released";
        }

        send(client_sock, response.c_str(), response.length(), 0);
        memset(buffer, 0, 1024);
    }
    close(client_sock);
}

int main(int argc, char const *argv[]) {
    print_ip_address(); // Вывод IP-адреса сервера

    int server_fd, new_socket;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);

    // Создание сокета
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    // Привязка сокета к порту
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt))) {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }
    if (listen(server_fd, 3) < 0) {
        perror("listen");
        exit(EXIT_FAILURE);
    }

    while (true) {
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen)) < 0) {
            perror("accept");
            exit(EXIT_FAILURE);
        }
        std::thread([new_socket]() { handle_client(new_socket); }).detach();
    }

    return 0;
}
